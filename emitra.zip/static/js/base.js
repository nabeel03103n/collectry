drop = () => {
    dropdown = document.getElementById("select_navs")
    console.log(select_navs.value)
}