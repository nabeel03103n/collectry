import requests

# Define the URL
url = "http://emitrauat.rajasthan.gov.in/webServicesRepositoryUat/getKioskDetailsJSON"

# Define the payload
payload = {
    "MERCHANTCODE": "RISLTEST",
    "SSOID": "DEEPAKDHAKARBAGRI"
}

# Define the headers if needed (adjust if your request needs specific headers)
headers = {
    "Content-Type": "application/x-www-form-urlencoded"
}

# Send the POST request
response = requests.post(url, data=payload, headers=headers)

# Print the response
if response.status_code == 200:
    print("Response JSON:")
    print(response.json())
else:
    print("Failed to get a response")
    print("Status code:", response.status_code)
    print("Response text:", response.text)
