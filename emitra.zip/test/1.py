import requests
from requests.auth import HTTPBasicAuth

# Define the data and authentication credentials
data = "requestMsg=pay_DvZwlUY4qSQaKg|UATSG0000000052|410362220"
api_key = "UATSG0000000120"
password = "juflqunjuposxgghsjft"

# Define the URL
url = "http://121.242.223.243/SurePayPayment/v1/queryPaymentStatus"

# Set up the headers and authentication
headers = {'Content-Type': 'application/x-www-form-urlencoded'}
auth = HTTPBasicAuth(api_key, password)

# Make the POST request
response = requests.post(url, data=data, headers=headers, auth=auth, verify=False)

# Check for errors and print the result
if response.status_code == 200:
    print(response.text)
else:
    print(f"Error: {response.status_code}")
    print(response.text)
