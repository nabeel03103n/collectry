import requests
from django.views import View
from requests.auth import HTTPBasicAuth
from user import models
from django.shortcuts import render,HttpResponse
from django.http import JsonResponse
from requests.exceptions import ConnectionError, Timeout, HTTPError
import time
from django.shortcuts import render, redirect
from.nsdl_surepay import generate_checksum, process_payment_response
from django.conf import settings
from emitra.settings import MERCHANT_ID,SERVICE_ID,SECRET_KEY
import hashlib
import hmac
import base64
# Create your views here.



def index(request):
    # url = "http://emitrauat.rajasthan.gov.in/webServicesRepositoryUat/getKioskDetailsJSON"
    # payload = {
    # "MERCHANTCODE": "RISLTEST",
    # "SSOID": "DEEPAKDHAKARBAGRI"
    # }

    # headers = {
    # "Content-Type": "application/x-www-form-urlencoded"
    # }
    
    # response = requests.post(url, data=payload, headers=headers)
    # if response.status_code == 200:
    #     arguments = list(response.json().items())            
    #     text = {"t1":arguments}
    # else:
    #     print("Failed to get a response")
    #     print("Status code:", response.status_code)
    #     print("Response text:", response.text)

    return render(request,"index.html")

def about(request):
    return render(request,"about.html")

def contact(request):
    if request.method == 'POST':

        name = request.POST.get("name")
        email = request.POST.get("email")
        tel = request.POST.get("tel")
        state = request.POST.get('state')
        city = request.POST.get('city')
        pincode = request.POST.get('pincode')
        msg = request.POST.get("message")
        ins = models.Contact(name=name,email=email,tel=tel,state=state,city=city,pincode=pincode,msg=msg)
        ins.save()
        print("The data has been written to the database")
        

    return render(request,"contact.html")
 
def services(request):
    return render(request,"services.html")

def applications(request):
    return render(request,"applications.html")

def donations(request):
    return render(request,'donations.html')

def newbranch(request):
    return render(request, 'newbranch.html')

def payment_page(request):
    return render(request,"query_payment_status.html")


def make_payment_request(request):
    # Set up the payment request parameters
    message_type = '0100'
    merchant_id = MERCHANT_ID
    service_id = SERVICE_ID
    order_id = '123456'
    customer_id = '987654'
    transaction_amount = '100.00'
    currency_code = 'INR'
    request_datetime = '2023-03-22 10:30:00'
    success_url = 'https://127.0.0.1/success'
    fail_url = 'https://127.0.0.1/failure'
    additional_field1 = ''
    additional_field2 = ''
    additional_field3 = ''
    additional_field4 = ''
    additional_field5 = ''

    # Concatenate the parameters into a message string
    message = '|'.join([message_type, merchant_id, service_id, order_id, customer_id, transaction_amount, currency_code, request_datetime, success_url, fail_url, additional_field1, additional_field2, additional_field3, additional_field4, additional_field5])

    # Calculate the checksum using the HMAC-SHA256 algorithm
    secret_key = settings.SECRET_KEY.encode()
    message = message.encode()
    checksum = hmac.new(secret_key, message, hashlib.sha256).hexdigest()

    # Send the payment request to the NSDL SurePay API
    url = 'https://pilot.surepay.ndml.in/SurePayPayment/sp/processRequest'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    data = {
        'messageType': message_type,
        'merchantId': merchant_id,
        'serviceId': service_id,
        'orderId': order_id,
        'customerId': customer_id,
        'transactionAmount': transaction_amount,
        'currencyCode': currency_code,
        'requestDateTime': request_datetime,
        'successUrl': success_url,
        'failUrl': fail_url,
        'additionalField1': additional_field1,
        'additionalField2': additional_field2,
        'additionalField3': additional_field3,
        'additionalField4': additional_field4,
        'additionalField5': additional_field5,
        'checksum': checksum,
    }
    response = requests.post(url, headers=headers, data=data)

    # Process the response from the NSDL SurePay API
    if response.status_code == 200:
        # Handle a successful payment request
        return render(request, 'make_payment.html')
    else:
        return HttpResponse("Error",request)

    return render(request, 'make_payment.html')