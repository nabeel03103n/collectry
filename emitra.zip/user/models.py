from django.db import models
from django.utils import timezone
import datetime

# Create your models here.

class Contact(models.Model):
    name = models.CharField(max_length=30)
    email = models.EmailField(max_length=30)
    tel = models.CharField(max_length=10)
    state = models.CharField(max_length=30) 
    city = models.CharField(max_length=30)
    pincode = models.CharField(max_length=30)
    msg = models.TextField()
    def __str__(self):
        objName = f"{self.name} {self.pincode} {datetime.date.today()}"
        return objName