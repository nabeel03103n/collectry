import hashlib
import requests
from emitra.settings import MERCHANT_ID,SERVICE_ID,SECRET_KEY
# NSDL SurePay API credentials


# NSDL SurePay API URLs
PAYMENT_GATEWAY_URL = 'https://pilot.surepay.ndml.in/SurePayPayment/sp/processRequest'
QUERY_API_URL = 'https://pilot.surepay.ndml.in/SurePayPayment/sp/queryRequest'

def generate_checksum(message):
    """
    Generate a checksum for the given message using the SECRET_KEY.
    """
    msg = message + "|" + SECRET_KEY
    result = hashlib.new('crc32')
    result.update(msg.encode('utf-8'))
    return result.hexdigest()

def process_payment_request(message):
    """
    Process a payment request by redirecting the user to the NSDL SurePay payment gateway.
    """
    checksum = generate_checksum(message)
    url = PAYMENT_GATEWAY_URL + "?message=" + message + "&checksum=" + checksum
    return url

def process_payment_response(response):
    """
    Process a payment response from NSDL SurePay.
    """
    # Parse the response and extract the relevant information
    response_dict = {}
    for pair in response.split("|"):
        key, value = pair.split("=")
        response_dict[key] = value

    # Check if the payment was successful
    if response_dict['status'] == 'success':
        # Update the order status and send a confirmation email
        print("passed 46")
    else:
        # Handle the payment failure
        print("line 46")

def query_payment_status(transaction_id):
    """
    Query the payment status for a given transaction ID.
    """
    message = "0100|" + MERCHANT_ID + "|" + SERVICE_ID + "|" + transaction_id + "|"
    checksum = generate_checksum(message)
    url = QUERY_API_URL + "?message=" + message + "&checksum=" + checksum
    response = requests.get(url)
    return response.text